# Dataset2 Model Package
Algorithm: LightGBM (classification)
Target: Class
Rows/columns: [21752, 77] -> [21752, 77]
Split: {'train': 15225, 'validation': 2176, 'test': 4351, 'method': '70/10/20 stratified random split'}
Load:
import joblib
model = joblib.load('trained_model.joblib')
predictions = model.predict(new_dataframe)
Notes: Exact duplicate rows removed; missing values handled in pipeline; no SMOTE, oversampling, undersampling, or synthetic records were used. Dataset4 is regression because QueueRank is numeric rather than a class label.
