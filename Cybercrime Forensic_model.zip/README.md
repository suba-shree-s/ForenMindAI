Algorithm: LightGBM Classifier
Target: Label
No SMOTE or synthetic records used.
