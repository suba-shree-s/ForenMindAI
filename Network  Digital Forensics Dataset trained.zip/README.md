# Dataset3 Model Package
Algorithm: LightGBM (classification)
Target: Uses_Anti_Forensics
Rows/columns: [9721, 13] -> [9721, 13]
Split: {'train': 6804, 'validation': 972, 'test': 1945, 'method': '70/10/20 split after timestamp parsing; timestamp-derived features only'}
Load:
import joblib
model = joblib.load('trained_model.joblib')
predictions = model.predict(new_dataframe)
Notes: Exact duplicate rows removed; missing values handled in pipeline; no SMOTE, oversampling, undersampling, or synthetic records were used. Dataset4 is regression because QueueRank is numeric rather than a class label.
