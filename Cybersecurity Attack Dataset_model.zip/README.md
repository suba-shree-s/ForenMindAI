Algorithm: LightGBM Classifier
Target: Category
No SMOTE or synthetic records used.
