# Dataset4 Model Package
Algorithm: LightGBM (regression)
Target: QueueRank
Rows/columns: [9980, 3] -> [9980, 3]
Split: {'train': 6986, 'validation': 998, 'test': 1996, 'method': '70/10/20 stratified random split'}
Load:
import joblib
model = joblib.load('trained_model.joblib')
predictions = model.predict(new_dataframe)
Notes: Exact duplicate rows removed; missing values handled in pipeline; no SMOTE, oversampling, undersampling, or synthetic records were used. Dataset4 is regression because QueueRank is numeric rather than a class label.
