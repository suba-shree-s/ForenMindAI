# Dataset1 Model Package
Algorithm: LightGBM (classification)
Target: relation_type
Rows/columns: [476, 18] -> [432, 18]
Split: {'train': 301, 'validation': 44, 'test': 87, 'method': '70/10/20 stratified random split'}
Load:
import joblib
model = joblib.load('trained_model.joblib')
predictions = model.predict(new_dataframe)
Notes: Exact duplicate rows removed; missing values handled in pipeline; no SMOTE, oversampling, undersampling, or synthetic records were used. Dataset4 is regression because QueueRank is numeric rather than a class label.
