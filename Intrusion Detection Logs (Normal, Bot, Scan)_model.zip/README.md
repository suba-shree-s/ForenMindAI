Algorithm: LightGBM Classifier
Target: Intrusion
No SMOTE or synthetic records used.
